################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -l"ti/display/lib/display.aem4f" -l"ti/grlib/lib/ccs/m4f/grlib.a" -l"third_party/spiffs/lib/ccs/m4f/spiffs.a" -l"ti/drivers/lib/drivers_msp432e4.aem4f" -l"third_party/fatfs/lib/ccs/m4f/fatfs.a" -l"ti/net/lib/ccs/m4f/slnetsock_release.a" -l"ti/net/sntp/lib/ccs/m4f/sntp_release.a" -l"ti/net/mqtt/lib/ccs/m4f/mqtt_release.a" -l"ti/net/http/lib/ccs/m4f/httpclient_release.a" -l"ti/ndk/slnetif/lib/slnetifndk.aem4f" -l"third_party/mbedtls/ti/lib/ccs/m4f/mbedtls.a" -l"ti/ndk/hal/timer_bios/lib/hal_timer.aem4f" -l"ti/ndk/hal/eth_stub/lib/hal_eth_stub.aem4f" -l"ti/ndk/tools/hdlc/lib/hdlc.aem4f" -l"ti/ndk/tools/console/lib/console_min_ipv4.aem4f" -l"ti/ndk/netctrl/lib/netctrl_min_ipv4.aem4f" -l"ti/ndk/nettools/lib/nettool_ipv4.aem4f" -l"ti/ndk/hal/ser_stub/lib/hal_ser_stub.aem4f" -l"ti/ndk/tools/servers/lib/servers_min_ipv4.aem4f" -l"ti/ndk/hal/userled_stub/lib/hal_userled_stub.aem4f" -l"ti/ndk/stack/lib/stk.aem4f" -l"ti/ndk/os/lib/os_freertos.aem4f" -lfreertos_builds_MSP_EXP432E401Y_release_ccs.lib -l"ti/devices/msp432e4/driverlib/lib/ccs/m4f/msp432e4_driverlib.a" -llibc.a

