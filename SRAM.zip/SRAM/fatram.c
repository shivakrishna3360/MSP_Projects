#include <file.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <pthread.h>
#include <third_party/fatfs/ff.h>
#include <third_party/fatfs/ffcio.h>

#include <ti/display/Display.h>
#include <ti/drivers/GPIO.h>

#include "ti_drivers_config.h"
#include <fat_driver/ramdisk.h>

#ifndef CPY_BUFF_SIZE
#define CPY_BUFF_SIZE       1024
#endif

#define STR_(n)             #n
#define STR(n)              STR_(n)
#define DRIVE_NUM           0

const char inputfile[]  = "fat:"STR(DRIVE_NUM)":input.txt";
const char outputfile[] = "fat:"STR(DRIVE_NUM)":output.txt";

const char textarray[] = \
"***********************************************************************\n"
"0         1         2         3         4         5         6         7\n"
"01234567890123456789012345678901234567890123456789012345678901234567890\n"
"This text is stored in the MSP432E401Y internal SRAM FAT filesystem.\n"
"***********************************************************************\n";

static FATFS fatfsObj;
static Display_Handle display;

const struct timespec ts = {
    .tv_sec = 1469647026,
    .tv_nsec = 0
};

char fatfsPrefix[] = "fat";
unsigned char cpy_buff[CPY_BUFF_SIZE];

void *mainThread(void *arg0)
{
    FILE *src, *dst;
    unsigned int bytesRead = 0;
    unsigned int bytesWritten = 0;
    unsigned int filesize;
    unsigned int totalBytesCopied = 0;
    int result;
    FRESULT fresult;
    BYTE mkfsWork[FF_MAX_SS];

    GPIO_init();
    Display_init();

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    add_device(fatfsPrefix, _MSA, ffcio_open, ffcio_close, ffcio_read,
        ffcio_write, ffcio_lseek, ffcio_unlink, ffcio_rename);

    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }

    clock_settime(CLOCK_REALTIME, &ts);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    Display_printf(display, 0, 0, "Starting the SRAM FatFs example\n");

    /* 1. Register SRAM disk via separate driver module */
    if (ramdisk_register(DRIVE_NUM) != RES_OK) {
        Display_printf(display, 0, 0, "Error registering SRAM drive\n");
        while (1);
    }

    /* 2. Format SRAM drive */
    fresult = f_mkfs(STR(DRIVE_NUM)":", FM_FAT | FM_SFD, 0, mkfsWork, sizeof(mkfsWork));
    if (fresult != FR_OK) {
        Display_printf(display, 0, 0, "Error formatting SRAM drive: %d\n", fresult);
        while (1);
    }

    /* 3. Mount SRAM drive */
    fresult = f_mount(&fatfsObj, STR(DRIVE_NUM)":", 1);
    if (fresult != FR_OK) {
        Display_printf(display, 0, 0, "Error mounting SRAM drive: %d\n", fresult);
        while (1);
    }
    Display_printf(display, 0, 0, "Drive %u is mounted in SRAM (%u KB)\n",
                   DRIVE_NUM, RAMDISK_SIZE_BYTES / 1024);

    /* Write input.txt */
    src = fopen(inputfile, "w+");
    if (!src) {
        Display_printf(display, 0, 0, "Error creating \"%s\"\n", inputfile);
        while (1);
    }
    fwrite(textarray, 1, strlen(textarray), src);
    fflush(src);
    rewind(src);

    /* Copy input.txt to output.txt */
    dst = fopen(outputfile, "w");
    if (!dst) {
        Display_printf(display, 0, 0, "Error opening \"%s\"\n", outputfile);
        while (1);
    }

    result = setvbuf(dst, NULL, _IONBF, 0);
    if (result != 0) {
        Display_printf(display, 0, 0, "Call to setvbuf failed!\n");
    }

    while (true) {
        bytesRead = fread(cpy_buff, 1, CPY_BUFF_SIZE, src);
        if (bytesRead == 0) {
            break;
        }
        bytesWritten = fwrite(cpy_buff, 1, bytesRead, dst);
        if (bytesWritten < bytesRead) {
            Display_printf(display, 0, 0, "Disk Full\n");
            break;
        }
        totalBytesCopied += bytesWritten;
    }

    fflush(dst);

    fseek(src, 0, SEEK_END);
    filesize = ftell(src);
    rewind(src);

    fclose(src);
    fclose(dst);

    Display_printf(display, 0, 0,
        "File \"%s\" (%u B) copied to \"%s\" (Wrote %u B)\n",
        inputfile, filesize, outputfile, totalBytesCopied);

    /* Read back output.txt */
    dst = fopen(outputfile, "r");
    if (!dst) {
        Display_printf(display, 0, 0, "Error opening \"%s\"\n", outputfile);
        while (1);
    }

    while (true) {
        bytesRead = fread(cpy_buff, 1, CPY_BUFF_SIZE - 1, dst);
        if (bytesRead == 0) {
            break;
        }
        cpy_buff[bytesRead] = '\0';
        Display_printf(display, 0, 0, "%s", cpy_buff);
    }

    fclose(dst);

    /* Cleanup */
    f_unmount(STR(DRIVE_NUM)":");
    ramdisk_unregister(DRIVE_NUM);
    Display_printf(display, 0, 0, "Drive %u unmounted\n", DRIVE_NUM);

    return (NULL);
}

int32_t fatfs_getFatTime(void)
{
    time_t seconds;
    uint32_t fatTime;
    struct tm *pTime;

    seconds = time(NULL);
    pTime = localtime(&seconds);

    fatTime = ((uint32_t)(pTime->tm_year - 80) << 25) |
        ((uint32_t)(pTime->tm_mon + 1) << 21) |
        ((uint32_t)(pTime->tm_mday) << 16) |
        ((uint32_t)(pTime->tm_hour) << 11) |
        ((uint32_t)(pTime->tm_min) << 5) |
        ((uint32_t)(pTime->tm_sec) >> 1);

    return ((int32_t)fatTime);
}
