#include <string.h>
#include "ramdisk.h"

/* 64 KB SRAM buffer aligned to 4 bytes for fast memcpy */
static uint8_t ramDisk[RAMDISK_SIZE_BYTES] __attribute__((aligned(4)));
/* Place in the dedicated SRAM_DISK memory region */
//static uint8_t ramDisk[RAMDISK_SIZE_BYTES] __attribute__((aligned(4), section(".ramdisk")));
static DSTATUS ramDiskStat = STA_NOINIT;
static BYTE registeredDrive = 0xFF;

static DSTATUS ramdisk_init(BYTE drv)
{
    if (drv != registeredDrive) {
        return STA_NOINIT;
    }
    ramDiskStat &= ~STA_NOINIT;
    return ramDiskStat;
}

static DSTATUS ramdisk_status(BYTE drv)
{
    if (drv != registeredDrive) {
        return STA_NOINIT;
    }
    return ramDiskStat;
}

static DRESULT ramdisk_read(BYTE drv, BYTE *buff, DWORD sector, UINT count)
{
    if (drv != registeredDrive || (ramDiskStat & STA_NOINIT)) {
        return RES_NOTRDY;
    }
    if ((sector + count) > RAMDISK_SECTOR_COUNT) {
        return RES_PARERR;
    }

    memcpy(buff, &ramDisk[sector * RAMDISK_SECTOR_SIZE], count * RAMDISK_SECTOR_SIZE);
    return RES_OK;
}

static DRESULT ramdisk_write(BYTE drv, const BYTE *buff, DWORD sector, UINT count)
{
    if (drv != registeredDrive || (ramDiskStat & STA_NOINIT)) {
        return RES_NOTRDY;
    }
    if ((sector + count) > RAMDISK_SECTOR_COUNT) {
        return RES_PARERR;
    }

    memcpy(&ramDisk[sector * RAMDISK_SECTOR_SIZE], buff, count * RAMDISK_SECTOR_SIZE);
    return RES_OK;
}

static DRESULT ramdisk_ioctl(BYTE drv, BYTE cmd, void *buff)
{
    if (drv != registeredDrive || (ramDiskStat & STA_NOINIT)) {
        return RES_NOTRDY;
    }

    switch (cmd) {
        case CTRL_SYNC:
            return RES_OK;

        case GET_SECTOR_COUNT:
            *(DWORD *)buff = RAMDISK_SECTOR_COUNT;
            return RES_OK;

        case GET_SECTOR_SIZE:
            *(WORD *)buff = RAMDISK_SECTOR_SIZE;
            return RES_OK;

        case GET_BLOCK_SIZE:
            *(DWORD *)buff = 1;
            return RES_OK;

        default:
            return RES_PARERR;
    }
}

DRESULT ramdisk_register(BYTE drive)
{
    DRESULT res = disk_register(drive,
                                ramdisk_init,
                                ramdisk_status,
                                ramdisk_read,
                                ramdisk_write,
                                ramdisk_ioctl);
    if (res == RES_OK) {
        registeredDrive = drive;
        ramDiskStat = STA_NOINIT;
    }
    return res;
}

DRESULT ramdisk_unregister(BYTE drive)
{
    DRESULT res = disk_unregister(drive);
    if (res == RES_OK) {
        registeredDrive = 0xFF;
        ramDiskStat = STA_NOINIT;
    }
    return res;
}


