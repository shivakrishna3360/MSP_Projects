

#ifndef FAT_DRIVER_RAMDISK_H_
#define FAT_DRIVER_RAMDISK_H_


#include <stdint.h>
#include "diskio.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 128 sectors * 512 bytes = 64 KB SRAM disk */
#define RAMDISK_SECTOR_SIZE     512
#define RAMDISK_SECTOR_COUNT    128
#define RAMDISK_SIZE_BYTES      (RAMDISK_SECTOR_SIZE * RAMDISK_SECTOR_COUNT)

/* Registers the SRAM disk I/O callbacks with FatFs diskio */
DRESULT ramdisk_register(BYTE drive);

/* Unregisters the SRAM disk from FatFs diskio */
DRESULT ramdisk_unregister(BYTE drive);

#ifdef __cplusplus
}
#endif


#endif /* FAT_DRIVER_RAMDISK_H_ */
