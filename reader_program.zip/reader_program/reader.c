#include <file.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <FreeRTOS.h>
#include <semphr.h>
#include <fat_driver/ff.h>
#include <fat_driver/ffcio.h>
#include <ti/display/Display.h>
#include <ti/drivers/GPIO.h>
#include "ti_drivers_config.h"

#define TARGET_FILE     "fat:0:data.txt"
#define READ_BUFF_SIZE  512

static Display_Handle display;
static FATFS g_fatFs;
static char read_buffer[READ_BUFF_SIZE];

char fatfsPrefix[] = "fat";

void *mainThread(void *arg0)
{
    FILE *fp;
    FRESULT fresult;
    size_t bytesRead;

    GPIO_init();
    Display_init();

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Bind TI RTS C-IO functions to FatFs */
    add_device(fatfsPrefix, _MSA, ffcio_open, ffcio_close, ffcio_read,
               ffcio_write, ffcio_lseek, ffcio_unlink, ffcio_rename);

    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }

    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    Display_printf(display, 0, 0, "\n=== PROJECT 2: FILE READER ===\n");

    /* 1. Mount the existing flash drive (DO NOT FORMAT) */
    fresult = f_mount(&g_fatFs, "0:", 1);
    if (fresult == FR_NO_FILESYSTEM) {
        Display_printf(display, 0, 0, "Error: No filesystem found! (Did you run Project 1 first?)\n");
        while (1);
    } else if (fresult != FR_OK) {
        Display_printf(display, 0, 0, "Mount failed with code: %d\n", fresult);
        while (1);
    }
    Display_printf(display, 0, 0, "Flash drive 0 mounted successfully.\n");

    /* 2. Open the file written by Project 1 */
    Display_printf(display, 0, 0, "Opening \"%s\" for reading...\n", TARGET_FILE);
    fp = fopen(TARGET_FILE, "r");
    if (!fp) {
        Display_printf(display, 0, 0, "Error: \"%s\" not found on disk!\n", TARGET_FILE);
        f_mount(NULL, "0:", 0);
        while (1);
    }

    /* 3. Stream data to UART */
    Display_printf(display, 0, 0, "\n--- File Contents Start ---\n");
    while ((bytesRead = fread(read_buffer, 1, READ_BUFF_SIZE - 1, fp)) > 0) {
        read_buffer[bytesRead] = '\0';
        Display_printf(display, 0, 0, "%s", read_buffer);
    }
    Display_printf(display, 0, 0, "--- File Contents End ---\n\n");

    fclose(fp);

    /* 4. Unmount cleanly */
    f_mount(NULL, "0:", 0);
    Display_printf(display, 0, 0, "Drive unmounted successfully.\n");

    return NULL;
}

int32_t fatfs_getFatTime(void)
{
    return 0;
}

DWORD get_fattime(void)
{
    return 0;
}

#if FF_FS_REENTRANT
int ff_cre_syncobj(BYTE vol, FF_SYNC_t *sobj)
{
    *sobj = xSemaphoreCreateMutex();
    return (*sobj != NULL) ? 1 : 0;
}

int ff_del_syncobj(FF_SYNC_t sobj)
{
    vSemaphoreDelete(sobj);
    return 1;
}

int ff_req_grant(FF_SYNC_t sobj)
{
    return (xSemaphoreTake(sobj, pdMS_TO_TICKS(FF_FS_TIMEOUT)) == pdTRUE) ? 1 : 0;
}

void ff_rel_grant(FF_SYNC_t sobj)
{
    xSemaphoreGive(sobj);
}
#endif
