/*
 * lfs_port_msp432e4.c
 *
 *  Created on: 05-Nov-2026
 *
 */



#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <fs_driver/lfs.h>
#include <ti/devices/msp432e4/driverlib/flash.h>

#define LFS_FLASH_BASE_ADDR   0x000C0000UL     /* Origin of the last 256 KB */
#define LFS_ERASE_BLOCK_SIZE  16384UL          /* MSP432E4 erase sector is 16 KB */
#define LFS_TOTAL_SIZE        (256UL * 1024UL) /* 256 KB */
#define LFS_BLOCK_COUNT       (LFS_TOTAL_SIZE / LFS_ERASE_BLOCK_SIZE) /* 16 blocks */

#define LFS_READ_SIZE         4UL              /* Flash 32-bit word alignment */
#define LFS_PROG_SIZE         4UL              /* FlashProgram requires 4-byte words */
#define LFS_CACHE_SIZE        64UL             /* Static cache buffer size */
#define LFS_LOOKAHEAD_SIZE    16UL             /* Lookahead buffer (minimum 16 bytes) */

static uint8_t s_read_buffer[LFS_CACHE_SIZE];
static uint8_t s_prog_buffer[LFS_CACHE_SIZE];
static uint8_t s_lookahead_buffer[LFS_LOOKAHEAD_SIZE];

/* Read callback */
static int msp432e4_lfs_read(const struct lfs_config *c, lfs_block_t block,
                             lfs_off_t off, void *buffer, lfs_size_t size)
{
    uint32_t addr = LFS_FLASH_BASE_ADDR + (block * c->block_size) + off;
    memcpy(buffer, (const void *)addr, size);
    return LFS_ERR_OK;
}

/* Program callback */
static int msp432e4_lfs_prog(const struct lfs_config *c, lfs_block_t block,
                             lfs_off_t off, const void *buffer, lfs_size_t size)
{
    uint32_t addr = LFS_FLASH_BASE_ADDR + (block * c->block_size) + off;

    /* FlashProgram writes 32-bit aligned words into flash */
    int32_t status = FlashProgram((uint32_t *)buffer, addr, size);
    return (status == 0) ? LFS_ERR_OK : LFS_ERR_IO;
}

/* Erase callback */
static int msp432e4_lfs_erase(const struct lfs_config *c, lfs_block_t block)
{
    uint32_t addr = LFS_FLASH_BASE_ADDR + (block * c->block_size);

    int32_t status = FlashErase(addr);
    return (status == 0) ? LFS_ERR_OK : LFS_ERR_IO;
}

/* Sync callback */
static int msp432e4_lfs_sync(const struct lfs_config *c)
{
    return LFS_ERR_OK;
}

const struct lfs_config g_lfs_cfg = {
    .read  = msp432e4_lfs_read,
    .prog  = msp432e4_lfs_prog,
    .erase = msp432e4_lfs_erase,
    .sync  = msp432e4_lfs_sync,

    .read_size      = LFS_READ_SIZE,
    .prog_size      = LFS_PROG_SIZE,
    .block_size     = LFS_ERASE_BLOCK_SIZE,
    .block_count    = LFS_BLOCK_COUNT,
    .cache_size     = LFS_CACHE_SIZE,
    .lookahead_size = LFS_LOOKAHEAD_SIZE,
    .block_cycles   = 500,

    .read_buffer      = s_read_buffer,
    .prog_buffer      = s_prog_buffer,
    .lookahead_buffer = s_lookahead_buffer
};
