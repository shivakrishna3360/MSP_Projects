/*
 * lfs_port_msp432e4.h
 *
 *  Created on: 05-Nov-2026
 *      Author: chatlapallipavangoud
 */

#ifndef LFS_PORT_MSP432E4_H_
#define LFS_PORT_MSP432E4_H_


#include <fs_driver/lfs.h>

extern const struct lfs_config g_lfs_cfg;


#endif /* LFS_PORT_MSP432E4_H_ */
