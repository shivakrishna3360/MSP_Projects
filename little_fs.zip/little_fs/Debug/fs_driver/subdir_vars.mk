################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../fs_driver/lfs.c \
../fs_driver/lfs_util.c 

C_DEPS += \
./fs_driver/lfs.d \
./fs_driver/lfs_util.d 

OBJS += \
./fs_driver/lfs.obj \
./fs_driver/lfs_util.obj 

OBJS__QUOTED += \
"fs_driver\lfs.obj" \
"fs_driver\lfs_util.obj" 

C_DEPS__QUOTED += \
"fs_driver\lfs.d" \
"fs_driver\lfs_util.d" 

C_SRCS__QUOTED += \
"../fs_driver/lfs.c" \
"../fs_driver/lfs_util.c" 


