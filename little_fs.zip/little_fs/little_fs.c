#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* POSIX / Drivers */
#include <pthread.h>
#include <ti/display/Display.h>
#include <ti/drivers/GPIO.h>
#include "ti_drivers_config.h"

/* LittleFS headers */
#include <fs_driver/lfs.h>
#include "lfs_port_msp432e4.h"

#define CPY_BUFF_SIZE 128

static Display_Handle display;
static lfs_t lfs;
static lfs_file_t file_src;
static lfs_file_t file_dst;

static const char inputfile[] = "input.txt";
static const char outputfile[] = "output.txt";

static const char textarray[] =
"***********************************************************************\r\n"
"MSP432E401Y LittleFS on Internal Flash (256 KB Region)\r\n"
"Power-resilient filesystem write and read operation verified!\r\n"
"***********************************************************************\r\n";

static char cpy_buff[CPY_BUFF_SIZE];

void *mainThread(void *arg0)
{
    int err;
    lfs_ssize_t bytesRead;
    lfs_ssize_t bytesWritten;

    GPIO_init();
    Display_init();

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }

    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    Display_printf(display, 0, 0, "\n--- Starting LittleFS on MSP432E4 Internal Flash ---\n");

    /* Step 1: Mount volume; auto-format if mount fails */
    err = lfs_mount(&lfs, &g_lfs_cfg);
    if (err) {
        Display_printf(display, 0, 0, "No valid LittleFS volume detected. Formatting 256KB flash...\n");
        err = lfs_format(&lfs, &g_lfs_cfg);
        if (err) {
            Display_printf(display, 0, 0, "Format failed with error: %d\n", err);
            while (1);
        }
        err = lfs_mount(&lfs, &g_lfs_cfg);
        if (err) {
            Display_printf(display, 0, 0, "Mount failed after format with error: %d\n", err);
            while (1);
        }
    }
    Display_printf(display, 0, 0, "LittleFS mounted successfully.\n");

    /* Step 2: Create input file if it does not exist */
    err = lfs_file_open(&lfs, &file_src, inputfile, LFS_O_RDWR | LFS_O_CREAT | LFS_O_EXCL);
    if (err == LFS_ERR_EXIST) {
        Display_printf(display, 0, 0, "Existing file \"%s\" found.\n", inputfile);
        lfs_file_open(&lfs, &file_src, inputfile, LFS_O_RDONLY);
    } else if (err == LFS_ERR_OK) {
        Display_printf(display, 0, 0, "Created new file \"%s\"...\n", inputfile);
        lfs_file_write(&lfs, &file_src, textarray, strlen(textarray));
        lfs_file_sync(&lfs, &file_src);
        lfs_file_rewind(&lfs, &file_src);
    } else {
        Display_printf(display, 0, 0, "Failed to open \"%s\" (error %d)\n", inputfile, err);
        while (1);
    }

    /* Step 3: Copy inputfile -> outputfile */
    err = lfs_file_open(&lfs, &file_dst, outputfile, LFS_O_WRONLY | LFS_O_CREAT | LFS_O_TRUNC);
    if (err) {
        Display_printf(display, 0, 0, "Failed to open destination file \"%s\" (error %d)\n", outputfile, err);
        while (1);
    }

    while ((bytesRead = lfs_file_read(&lfs, &file_src, cpy_buff, sizeof(cpy_buff))) > 0) {
        bytesWritten = lfs_file_write(&lfs, &file_dst, cpy_buff, bytesRead);
        if (bytesWritten < bytesRead) {
            Display_printf(display, 0, 0, "Write error or disk full!\n");
            break;
        }
    }

    lfs_file_close(&lfs, &file_src);
    lfs_file_close(&lfs, &file_dst);

    Display_printf(display, 0, 0, "File copy finished.\n");

    /* Step 4: Read outputfile and print via UART Display */
    err = lfs_file_open(&lfs, &file_dst, outputfile, LFS_O_RDONLY);
    if (err == LFS_ERR_OK) {
        Display_printf(display, 0, 0, "Reading back \"%s\":\n", outputfile);
        while ((bytesRead = lfs_file_read(&lfs, &file_dst, cpy_buff, sizeof(cpy_buff) - 1)) > 0) {
            cpy_buff[bytesRead] = '\0';
            Display_printf(display, 0, 0, "%s", cpy_buff);
        }
        lfs_file_close(&lfs, &file_dst);
    }

    /* Step 5: Unmount */
    lfs_unmount(&lfs);
    Display_printf(display, 0, 0, "LittleFS unmounted successfully.\n");

    return NULL;
}
