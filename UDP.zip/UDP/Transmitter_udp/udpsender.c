#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

/* BSD Socket headers */
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include <ti/display/Display.h>

#define TARGET_IP     "192.168.1.102"
#define TARGET_PORT   1000
#define PACKET_BUF    128

extern Display_Handle display;
extern void fdOpenSession();
extern void fdCloseSession();
extern void *TaskSelf();

void *udpSenderFxn(void *arg0)
{
    int sock = -1;
    struct sockaddr_in destAddr;
    char buffer[PACKET_BUF];
    int count = 0;
    int bytesSent;

    /* Register task with TI-NDK stack */
    fdOpenSession(TaskSelf());

    Display_printf(display, 0, 0, "=== Direct Cable: Board 1 (Sender) Ready ===");

    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        Display_printf(display, 0, 0, "Error: Could not open socket\n");
        goto shutdown;
    }

    memset(&destAddr, 0, sizeof(destAddr));
    destAddr.sin_family      = AF_INET;
    destAddr.sin_port        = htons(TARGET_PORT);
    /* 192.168.1.102 in network byte order */
    destAddr.sin_addr.s_addr = htonl((192U << 24) | (168U << 16) | (1U << 8) | 102U);
    //destAddr.sin_addr.s_addr = inet_addr(TARGET_IP);

    while (1) {
        snprintf(buffer, sizeof(buffer), "Ping from Board 1 [Seq: %d]", count++);

        bytesSent = sendto(sock, buffer, strlen(buffer), 0,
                           (struct sockaddr *)&destAddr, sizeof(destAddr));

        if (bytesSent < 0) {
            Display_printf(display, 0, 0, "Send failed (Cable disconnected?)\n");
        } else {
            Display_printf(display, 0, 0, "Sent (%d bytes): %s\n", bytesSent, buffer);
        }

        /* 1 second interval */
        sleep(1);
    }

shutdown:
    if (sock >= 0) {
        close(sock);
    }
    fdCloseSession(TaskSelf());
    return NULL;
}
