# FIXED

udpsender.obj: ../udpsender.c
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdio.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/unistd.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/pthread.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sched.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/bsd/netinet/in.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/slnetsock.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/time.h
udpsender.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/_timeval.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/bsd/arpa/inet.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/slnetutils.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/bsd/sys/socket.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/bsd/errnoutil.h
udpsender.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h

../udpsender.c: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdio.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/unistd.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/pthread.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sched.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/bsd/netinet/in.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/slnetsock.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/_timeval.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/bsd/arpa/inet.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/slnetutils.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/bsd/sys/socket.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/net/bsd/errnoutil.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h: 
