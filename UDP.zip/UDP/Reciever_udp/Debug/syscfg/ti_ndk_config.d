# FIXED

syscfg/ti_ndk_config.obj: syscfg/ti_ndk_config.c
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdlib.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/emac/EMACMSP432E4.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432e411y.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/core_cm4.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_version.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_compiler.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_ccs.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/mpu_armv7.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/system_msp432e411y.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pin_map.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stkmain.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stacksys.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/usertype.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/socket.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/socketndk.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/time.h
syscfg/ti_ndk_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/_timeval.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/serrno.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/os/osif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/hal/hal.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/_stack.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/stack.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/listlib.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/netdf.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/resif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/bindif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/etherif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/icmpif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/igmpif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/ipif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/lliif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/natif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/nodeif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/rawif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/routeif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/rtcif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/sockif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/fdtif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/pipeif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/tcpif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/udpif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/pppoeif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/pppif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/vlanif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/nimuif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/ip6if.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/bind6if.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/route6if.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/lli6if.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/icmp6if.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/mldif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/rawethif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/gpio/GPIOMSP432E4.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/gpio.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/netmain.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/_nettool.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/nettools.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/configif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/daemonif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/dhcpif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/dhcpsif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/dnsif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/inet.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/ipaddrif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/telnetif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/tftpif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/natif.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/dhcpopts.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/netcfg.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/_netctrl.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/netctrl/netctrl.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/netctrl/netsrv.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stkmain.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/_stack.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/os/oskern.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/os/NDK_SemaphoreP.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h
syscfg/ti_ndk_config.obj: D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h
syscfg/ti_ndk_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/semphr.h
syscfg/ti_ndk_config.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/queue.h

syscfg/ti_ndk_config.c: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdlib.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/emac/EMACMSP432E4.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432e411y.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/core_cm4.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_version.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_compiler.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_ccs.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/mpu_armv7.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/system_msp432e411y.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pin_map.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stkmain.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stacksys.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/usertype.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/socket.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/socketndk.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/_timeval.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/serrno.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/os/osif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/hal/hal.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/_stack.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/stack.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/listlib.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/netdf.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/resif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/bindif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/etherif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/icmpif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/igmpif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/ipif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/lliif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/natif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/nodeif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/rawif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/routeif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/rtcif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/sockif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/fdtif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/pipeif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/tcpif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/udpif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/pppoeif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/pppif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/vlanif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/nimuif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/ip6if.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/bind6if.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/route6if.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/lli6if.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/icmp6if.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/mldif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stack/inc/rawethif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/gpio/GPIOMSP432E4.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/gpio.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/netmain.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/_nettool.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/nettools.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/configif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/daemonif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/dhcpif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/dhcpsif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/dnsif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/inet.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/ipaddrif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/telnetif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/tftpif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/natif.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/inc/dhcpopts.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/nettools/netcfg.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/_netctrl.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/netctrl/netctrl.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/netctrl/netsrv.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/stkmain.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/_stack.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/inc/os/oskern.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/ndk/os/NDK_SemaphoreP.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h: 
D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/semphr.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/queue.h: 
