# FIXED

main_freertos.obj: ../main_freertos.c
main_freertos.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h
main_freertos.obj: D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h
main_freertos.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h
main_freertos.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h
main_freertos.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h
main_freertos.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h
main_freertos.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
main_freertos.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h
main_freertos.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h
main_freertos.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h
main_freertos.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h
main_freertos.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h
main_freertos.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Board.h

../main_freertos.c: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h: 
D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Board.h: 
