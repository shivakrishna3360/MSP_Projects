#include <string.h>
#include <stdint.h>
#include <stdio.h>
#include <pthread.h>

#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#include <ti/display/Display.h>
//.#include <ti/ndk/inc/netmain.h>

#define UDPPACKETSIZE 1472
#define LISTEN_PORT   1000

extern Display_Handle display;
extern void fdOpenSession();
extern void fdCloseSession();
extern void *TaskSelf();

void *udpReceiverFxn(void *arg0)
{
    int sock = -1;
    int bytesRcvd;
    struct sockaddr_in serverAddr;
    struct sockaddr_in clientAddr;
    socklen_t addrlen;
    char buffer[UDPPACKETSIZE];

    /* Register task with TI-NDK stack */
    fdOpenSession(TaskSelf());

    Display_printf(display, 0, 0, "=== Direct Cable: Board 2 (Receiver) Listening on port %d ===", LISTEN_PORT);

    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock < 0) {
        Display_printf(display, 0, 0, "Error: Could not open socket\n");
        goto shutdown;
    }

    memset(&serverAddr, 0, sizeof(serverAddr));
    serverAddr.sin_family      = AF_INET;
    serverAddr.sin_port        = htons(LISTEN_PORT);
    serverAddr.sin_addr.s_addr = htonl(INADDR_ANY);

    if (bind(sock, (struct sockaddr *)&serverAddr, sizeof(serverAddr)) < 0) {
        Display_printf(display, 0, 0, "Error: Bind failed\n");
        goto shutdown;
    }

    while (1)
    {
        addrlen = sizeof(clientAddr);
        bytesRcvd = recvfrom(sock, buffer, sizeof(buffer) - 1, 0, (struct sockaddr *)&clientAddr, &addrlen);
        if (bytesRcvd > 0)
        {
            buffer[bytesRcvd] = '\0';
            uint32_t ip = ntohl(clientAddr.sin_addr.s_addr);
            Display_printf(display, 0, 0, "[Received from %d.%d.%d.%d]: %s\n",(uint8_t)(ip>>24)&0xFF,(uint8_t)(ip>>16)&0xFF,(uint8_t)(ip>>8)&0xFF,
                           (uint8_t)(ip)&0xFF,buffer);
        }
    }

shutdown:
    if (sock >= 0) {
        close(sock);
    }
    fdCloseSession(TaskSelf());
    return NULL;
}
