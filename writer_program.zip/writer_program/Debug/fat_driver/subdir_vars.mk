################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../fat_driver/diskio.c \
../fat_driver/ff.c \
../fat_driver/ffcio.c \
../fat_driver/ffunicode.c 

C_DEPS += \
./fat_driver/diskio.d \
./fat_driver/ff.d \
./fat_driver/ffcio.d \
./fat_driver/ffunicode.d 

OBJS += \
./fat_driver/diskio.obj \
./fat_driver/ff.obj \
./fat_driver/ffcio.obj \
./fat_driver/ffunicode.obj 

OBJS__QUOTED += \
"fat_driver\diskio.obj" \
"fat_driver\ff.obj" \
"fat_driver\ffcio.obj" \
"fat_driver\ffunicode.obj" 

C_DEPS__QUOTED += \
"fat_driver\diskio.d" \
"fat_driver\ff.d" \
"fat_driver\ffcio.d" \
"fat_driver\ffunicode.d" 

C_SRCS__QUOTED += \
"../fat_driver/diskio.c" \
"../fat_driver/ff.c" \
"../fat_driver/ffcio.c" \
"../fat_driver/ffunicode.c" 


