# FIXED

fat_driver/ffunicode.obj: ../fat_driver/ffunicode.c
fat_driver/ffunicode.obj: ../fat_driver/ff.h
fat_driver/ffunicode.obj: ../fat_driver/integer.h
fat_driver/ffunicode.obj: ../fat_driver/ffconf.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h
fat_driver/ffunicode.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h
fat_driver/ffunicode.obj: D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h
fat_driver/ffunicode.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/semphr.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/queue.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h
fat_driver/ffunicode.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h

../fat_driver/ffunicode.c: 
../fat_driver/ff.h: 
../fat_driver/integer.h: 
../fat_driver/ffconf.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h: 
D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/semphr.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/queue.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h: 
