# FIXED

writer.obj: ../writer.c
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/file.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdio.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdlib.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h
writer.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h
writer.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h
writer.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h
writer.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h
writer.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h
writer.obj: D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h
writer.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/semphr.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/queue.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h
writer.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h
writer.obj: D:/MSP/writer_program/fat_driver/ff.h
writer.obj: D:/MSP/writer_program/fat_driver/integer.h
writer.obj: D:/MSP/writer_program/fat_driver/ffconf.h
writer.obj: D:/MSP/writer_program/fat_driver/ffcio.h
writer.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h
writer.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h
writer.obj: D:/MSP/writer_program/Debug/syscfg/ti_drivers_config.h
writer.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h

../writer.c: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/file.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdio.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdlib.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h: 
D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/semphr.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/queue.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h: 
D:/MSP/writer_program/fat_driver/ff.h: 
D:/MSP/writer_program/fat_driver/integer.h: 
D:/MSP/writer_program/fat_driver/ffconf.h: 
D:/MSP/writer_program/fat_driver/ffcio.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h: 
D:/MSP/writer_program/Debug/syscfg/ti_drivers_config.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h: 
