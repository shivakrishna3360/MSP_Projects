/*
 * fatfs_flash_diskio.c
 *
 *  Created on: 04-Nov-2026
 *      Author: chatlapallipavangoud
 */

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <fat_driver/diskio.h>
#include <ti/devices/msp432e4/driverlib/flash.h>

#define FLASH_FS_BASE_ADDR     0x000C0000UL        /* Base address of last 256KB */
#define FLASH_FS_TOTAL_SIZE    (256UL * 1024UL)    /* 256 KB volume */
#define FLASH_SECTOR_SIZE      512UL               /* Standard FatFs sector size */
#define FLASH_ERASE_BLOCK_SIZE 16384UL             /* MSP432E4 hardware erase block (16 KB) */
#define FLASH_SECTOR_COUNT     (FLASH_FS_TOTAL_SIZE / FLASH_SECTOR_SIZE) /* 512 sectors */

/* 16 KB RAM bounce buffer for block read-modify-write operations */
static uint8_t s_blockBuffer[FLASH_ERASE_BLOCK_SIZE];

DSTATUS disk_initialize(BYTE pdrv)
{
    if (pdrv != 0) {
        return STA_NOINIT;
    }
    return 0;
}

DSTATUS disk_status(BYTE pdrv)
{
    if (pdrv != 0) {
        return STA_NOINIT;
    }
    return 0;
}

DRESULT disk_read(BYTE pdrv, BYTE *buff, DWORD sector, UINT count)
{
    if (pdrv != 0 || (sector + count) > FLASH_SECTOR_COUNT) {
        return RES_PARERR;
    }

    uint32_t srcAddr = FLASH_FS_BASE_ADDR + (sector * FLASH_SECTOR_SIZE);
    memcpy(buff, (const void *)srcAddr, count * FLASH_SECTOR_SIZE);

    return RES_OK;
}

DRESULT disk_write(BYTE pdrv, const BYTE *buff, DWORD sector, UINT count)
{
    if (pdrv != 0 || (sector + count) > FLASH_SECTOR_COUNT) {
        return RES_PARERR;
    }
    uint32_t i;
    for (i = 0; i < count; i++) {
        uint32_t currentSector = sector + i;
        uint32_t sectorByteOffset = currentSector * FLASH_SECTOR_SIZE;
        uint32_t blockBaseOffset = (sectorByteOffset / FLASH_ERASE_BLOCK_SIZE) * FLASH_ERASE_BLOCK_SIZE;
        uint32_t offsetInBlock = sectorByteOffset % FLASH_ERASE_BLOCK_SIZE;
        uint32_t blockPhysAddr = FLASH_FS_BASE_ADDR + blockBaseOffset;

        /* Step A: Copy 16KB erase block into RAM */
        memcpy(s_blockBuffer, (const void *)blockPhysAddr, FLASH_ERASE_BLOCK_SIZE);

        /* Step B: Modify the corresponding 512B sector */
        memcpy(&s_blockBuffer[offsetInBlock], &buff[i * FLASH_SECTOR_SIZE], FLASH_SECTOR_SIZE);

        /* Step C: Erase hardware block and rewrite updated content */
        FlashErase(blockPhysAddr);
        FlashProgram((uint32_t *)s_blockBuffer, blockPhysAddr, FLASH_ERASE_BLOCK_SIZE);
    }

    return RES_OK;
}

DRESULT disk_ioctl(BYTE pdrv, BYTE cmd, void *buff)
{
    if (pdrv != 0) {
        return RES_PARERR;
    }

    switch (cmd) {
        case CTRL_SYNC:
            return RES_OK;
        case GET_SECTOR_COUNT:
            *(DWORD *)buff = FLASH_SECTOR_COUNT;
            return RES_OK;
        case GET_SECTOR_SIZE:
            *(WORD *)buff = FLASH_SECTOR_SIZE;
            return RES_OK;
        case GET_BLOCK_SIZE:
            *(DWORD *)buff = FLASH_ERASE_BLOCK_SIZE / FLASH_SECTOR_SIZE; /* 32 sectors per block */
            return RES_OK;
        default:
            return RES_PARERR;
    }
}


