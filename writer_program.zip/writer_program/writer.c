#include <file.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <FreeRTOS.h>
#include <semphr.h>
#include <fat_driver/ff.h>
#include <fat_driver/ffcio.h>
#include <ti/display/Display.h>
#include <ti/drivers/GPIO.h>
#include "ti_drivers_config.h"

#define DRIVE_NUM       0
#define TARGET_FILE     "fat:0:data.txt"

static Display_Handle display;
static FATFS g_fatFs;

const struct timespec ts = {
    .tv_sec = 1762700000,
    .tv_nsec = 0
};

char fatfsPrefix[] = "fat";

/* Data payload to be preserved across reboot */
const char payloadData[] =
"===============================================\n"
"PROJECT 1: Persistent Data Storage Test\n"
"Board: MSP432E401Y Internal Flash (256 KB)\n"
"Status: Written successfully and power preserved!\n"
"===============================================\n";

void *mainThread(void *arg0)
{
    FILE *fp;
    FRESULT fresult;

    GPIO_init();
    Display_init();

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Bind TI RTS C-IO functions to FatFs */
    add_device(fatfsPrefix, _MSA, ffcio_open, ffcio_close, ffcio_read,
               ffcio_write, ffcio_lseek, ffcio_unlink, ffcio_rename);

    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }

    clock_settime(CLOCK_REALTIME, &ts);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    Display_printf(display, 0, 0, "\n=== PROJECT 1: FILE WRITER ===\n");

    /* 1. Mount the internal flash drive */
    fresult = f_mount(&g_fatFs, "0:", 1);
    if (fresult == FR_NO_FILESYSTEM) {
        Display_printf(display, 0, 0, "No filesystem found. Formatting 256KB flash area...\n");
        BYTE workBuf[FF_MAX_SS];
        fresult = f_mkfs("0:", FM_FAT, 0, workBuf, sizeof(workBuf));
        if (fresult != FR_OK) {
            Display_printf(display, 0, 0, "f_mkfs failed: %d\n", fresult);
            while (1);
        }
        Display_printf(display, 0, 0, "Format complete. Re-mounting...\n");
        fresult = f_mount(&g_fatFs, "0:", 1);
    }

    if (fresult != FR_OK) {
        Display_printf(display, 0, 0, "Mount failed: %d\n", fresult);
        while (1);
    }
    Display_printf(display, 0, 0, "Flash drive 0 mounted.\n");

    /* 2. Create and write to the file */
    Display_printf(display, 0, 0, "Opening \"%s\" for write...\n", TARGET_FILE);
    fp = fopen(TARGET_FILE, "w");
    if (!fp) {
        Display_printf(display, 0, 0, "Error: Could not open \"%s\" for write!\n", TARGET_FILE);
        while (1);
    }

    size_t written = fwrite(payloadData, 1, strlen(payloadData), fp);
    Display_printf(display, 0, 0, "Written %u bytes.\n", (unsigned int)written);

    /* Flush and close so data is committed to on-chip flash */
    fflush(fp);
    fclose(fp);
    Display_printf(display, 0, 0, "File written and closed successfully.\n");

    /* 3. Unmount cleanly */
    f_mount(NULL, "0:", 0);
    Display_printf(display, 0, 0, "Drive unmounted.\n");
    Display_printf(display, 0, 0, "You can now POWER OFF the board.\n");

    return NULL;
}

/* Time provider required by FatFs */
int32_t fatfs_getFatTime(void)
{
    time_t seconds = time(NULL);
    struct tm *pTime = localtime(&seconds);

    uint32_t fatTime = ((uint32_t)(pTime->tm_year - 80) << 25) |
                       ((uint32_t)(pTime->tm_mon) << 21) |
                       ((uint32_t)(pTime->tm_mday) << 16) |
                       ((uint32_t)(pTime->tm_hour) << 11) |
                       ((uint32_t)(pTime->tm_min) << 5) |
                       ((uint32_t)(pTime->tm_sec) >> 1);

    return ((int32_t)fatTime);
}

DWORD get_fattime(void)
{
    return (DWORD)fatfs_getFatTime();
}

#if FF_FS_REENTRANT
int ff_cre_syncobj(BYTE vol, FF_SYNC_t *sobj)
{
    *sobj = xSemaphoreCreateMutex();
    return (*sobj != NULL) ? 1 : 0;
}

int ff_del_syncobj(FF_SYNC_t sobj)
{
    vSemaphoreDelete(sobj);
    return 1;
}

int ff_req_grant(FF_SYNC_t sobj)
{
    return (xSemaphoreTake(sobj, pdMS_TO_TICKS(FF_FS_TIMEOUT)) == pdTRUE) ? 1 : 0;
}

void ff_rel_grant(FF_SYNC_t sobj)
{
    xSemaphoreGive(sobj);
}
#endif
