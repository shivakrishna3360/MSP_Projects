#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* POSIX Header files */
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>
#include <ti/display/Display.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#define THREADSTACKSIZE (1024)
#define SPI_MSG_LENGTH  (20)

static Display_Handle display;
static SPI_Handle     slaveSpi;
static sem_t          slaveTransferSem;

uint8_t slaveTxBuffer[SPI_MSG_LENGTH];
uint8_t slaveRxBuffer[SPI_MSG_LENGTH];

/*
 *  ======== spiCallbackFxn ========
 *  Triggered automatically when 20 bytes have been clocked in/out.
 */
void spiCallbackFxn(SPI_Handle handle, SPI_Transaction *transaction)
{
    sem_post(&slaveTransferSem);
}

/*
 *  ======== csEdgeFxn ========
 *  Optional: Detects Software CS edges for frame synchronization.
 */
void csEdgeFxn(uint_least8_t index)
{
    /* If CS goes HIGH before all 20 bytes arrived, cancel to stay byte-aligned */
    if (GPIO_read(CONFIG_SPI_CS) == 1) {
        SPI_transferCancel(slaveSpi);
    }
}

/*
 *  ======== slaveThread ========
 */
void *slaveThread(void *arg0)
{
    SPI_Params      spiParams;
    SPI_Transaction transaction;
    bool            transferOK;
    uint8_t         replyCounter = 0xA0;

    if (sem_init(&slaveTransferSem, 0, 0) != 0) {
        Display_printf(display, 0, 0, "Error creating slaveTransferSem\n");
        while (1);
    }

    /* Configure Software CS pin interrupt on rising edge to guard against partial frames */
    GPIO_setConfig(CONFIG_SPI_CS, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_RISING);
    GPIO_setCallback(CONFIG_SPI_CS, csEdgeFxn);
    GPIO_enableInt(CONFIG_SPI_CS);

    /* Configure SPI Slave in Mode 1 (POL0, PHA1) using Callback Mode */
    SPI_Params_init(&spiParams);
    spiParams.frameFormat         = SPI_POL0_PHA1;       /* Must match Master (Mode 1) */
    spiParams.bitRate             = 10000000;            /* Must be >= Master bitRate */
    spiParams.dataSize            = 8;                   /* 8-bit data frames */
    spiParams.mode                = SPI_SLAVE;
    spiParams.transferMode        = SPI_MODE_CALLBACK;   /* Non-blocking for CS sync */
    spiParams.transferCallbackFxn = spiCallbackFxn;

    slaveSpi = SPI_open(CONFIG_SPI_SLAVE, &spiParams);
    if (slaveSpi == NULL) {
        Display_printf(display, 0, 0, "Error initializing slave SPI\n");
        while (1);
    }

    Display_printf(display, 0, 0, "Slave SPI initialized (Mode 1, waiting for 20 bytes)\n");

    while (1) {
        /* Prepare 20-byte TX response before Master clocks it out */
        for (int i = 0; i < SPI_MSG_LENGTH; i++) {
            slaveTxBuffer[i] = replyCounter + i;
        }
        memset(slaveRxBuffer, 0x00, SPI_MSG_LENGTH);

        transaction.count = SPI_MSG_LENGTH;
        transaction.txBuf = (void *)slaveTxBuffer;
        transaction.rxBuf = (void *)slaveRxBuffer;

        /* Arm the SPI slave peripheral */
        transferOK = SPI_transfer(slaveSpi, &transaction);
        if (!transferOK) {
            Display_printf(display, 0, 0, "Error arming slave SPI transfer");
            while (1);
        }

        /* Wait until 20 bytes complete OR CS rises early */
        sem_wait(&slaveTransferSem);

        if (transaction.status == SPI_TRANSFER_COMPLETED) {
            GPIO_toggle(CONFIG_GPIO_LED_1);
            Display_printf(display, 0, 0, "Slave RX[0..3]: 0x%02X 0x%02X 0x%02X 0x%02X",
                           slaveRxBuffer[0], slaveRxBuffer[1],
                           slaveRxBuffer[2], slaveRxBuffer[3]);
            replyCounter++;
        }
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    pthread_t          thread0;
    pthread_attr_t     attrs;
    struct sched_param priParam;
    int                retc;

    Display_init();
    GPIO_init();
    SPI_init();

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }

    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    pthread_attr_init(&attrs);
    pthread_attr_setdetachstate(&attrs, PTHREAD_CREATE_DETACHED);
    pthread_attr_setstacksize(&attrs, THREADSTACKSIZE);
    priParam.sched_priority = 1;
    pthread_attr_setschedparam(&attrs, &priParam);

    retc = pthread_create(&thread0, &attrs, slaveThread, NULL);
    if (retc != 0) {
        while (1);
    }

    return (NULL);
}
