#include <stddef.h>
#include <stdint.h>
#include <string.h>

/* POSIX Header files */
#include <pthread.h>
#include <unistd.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>
#include <ti/drivers/SPI.h>
#include <ti/display/Display.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#define THREADSTACKSIZE (1024)
#define SPI_MSG_LENGTH  (20)

static Display_Handle display;

uint8_t masterTxBuffer[SPI_MSG_LENGTH];
uint8_t masterRxBuffer[SPI_MSG_LENGTH];

/*
 *  ======== masterThread ========
 */
void *masterThread(void *arg0)
{
    SPI_Handle      masterSpi;
    SPI_Params      spiParams;
    SPI_Transaction transaction;
    bool            transferOK;
    uint8_t         packetCounter = 0;

    /* Ensure Software CS starts HIGH (idle) */
    GPIO_write(CONFIG_SPI_CS, 1);

    /* Configure SPI Master in Mode 1 (POL0, PHA1) */
    SPI_Params_init(&spiParams);
    spiParams.frameFormat = SPI_POL0_PHA1;  /* SPI Mode 1 */
    spiParams.bitRate     = 10000000;       /* 10 MHz (adjust as needed) */
    spiParams.dataSize    = 8;              /* 8-bit data frames */
    spiParams.mode        = SPI_MASTER;

    masterSpi = SPI_open(CONFIG_SPI_MASTER, &spiParams);
    if (masterSpi == NULL) {
        Display_printf(display, 0, 0, "Error initializing master SPI\n");
        while (1);
    }

    Display_printf(display, 0, 0, "Master SPI initialized (Mode 1, 20-byte frames)\n");

    while (1)
       {
        /* Populate 20-byte TX payload */
        for (int i = 0; i < SPI_MSG_LENGTH; i++) {
            masterTxBuffer[i] = packetCounter + i;
        }
        memset(masterRxBuffer, 0x00, SPI_MSG_LENGTH);

        transaction.count = SPI_MSG_LENGTH;
        transaction.txBuf = (void *)masterTxBuffer;
        transaction.rxBuf = (void *)masterRxBuffer;

        /* 1. Pull Software CS LOW to frame the 20-byte transaction */
        GPIO_write(CONFIG_SPI_CS, 0);

        /* 2. Transmit and receive 20 bytes simultaneously */
        transferOK = SPI_transfer(masterSpi, &transaction);

        /* 3. Pull Software CS HIGH to end transaction */
        GPIO_write(CONFIG_SPI_CS, 1);

        if (transferOK) {
            GPIO_toggle(CONFIG_GPIO_LED_1);
            Display_printf(display, 0, 0, "Packet %d RX[0..3]: 0x%02X 0x%02X 0x%02X 0x%02X",
                           packetCounter,
                           masterRxBuffer[0], masterRxBuffer[1],
                           masterRxBuffer[2], masterRxBuffer[3]);
        }
        else {
            Display_printf(display, 0, 0, "Unsuccessful master SPI transfer");
        }

        packetCounter++;
        usleep(100000); /* 100 ms delay between packets */
    }
}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    pthread_t          thread0;
    pthread_attr_t     attrs;
    struct sched_param priParam;
    int                retc;

    Display_init();
    GPIO_init();
    SPI_init();

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }

    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    pthread_attr_init(&attrs);
    pthread_attr_setdetachstate(&attrs, PTHREAD_CREATE_DETACHED);
    pthread_attr_setstacksize(&attrs, THREADSTACKSIZE);
    priParam.sched_priority = 1;
    pthread_attr_setschedparam(&attrs, &priParam);

    retc = pthread_create(&thread0, &attrs, masterThread, NULL);
    if (retc != 0) {
        while (1);
    }

    return (NULL);
}
