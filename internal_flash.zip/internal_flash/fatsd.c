#include <file.h>
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include <FreeRTOS.h>
#include <semphr.h>
#include  <fat_driver/ff.h>
#include <time.h>





/* POSIX Header files */
#include <pthread.h>

/* FatFs core and CIO binding */

#include <fat_driver/ffcio.h>

#include <ti/display/Display.h>
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#ifndef CPY_BUFF_SIZE
#define CPY_BUFF_SIZE       2048
#endif

#define STR_(n)             #n
#define STR(n)              STR_(n)

#define DRIVE_NUM           0

const char inputfile[] = "fat:"STR(DRIVE_NUM)":input.txt";
const char outputfile[] = "fat:"STR(DRIVE_NUM)":output.txt";

const char textarray[] = \
"***********************************************************************\n"
"MSP432E401Y Internal Flash FAT Filesystem (256 KB Region)\n"
"Data read and written to on-chip flash memory successfully.\n"
"***********************************************************************\n";

static Display_Handle display;
static FATFS g_fatFs;

const struct timespec ts = {
    .tv_sec = 1469647026,
    .tv_nsec = 0
};

char fatfsPrefix[] = "fat";
unsigned char cpy_buff[CPY_BUFF_SIZE];

void *mainThread(void *arg0)
{
    FILE *src, *dst;
    unsigned int bytesRead = 0;
    unsigned int bytesWritten = 0;
    unsigned int filesize;
    unsigned int totalBytesCopied = 0;
    FRESULT fresult;

    GPIO_init();
    Display_init();

    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);

    /* Bind TI RTS C-IO functions (fopen, fread, fwrite) to FatFs */
    add_device(fatfsPrefix, _MSA, ffcio_open, ffcio_close, ffcio_read,
        ffcio_write, ffcio_lseek, ffcio_unlink, ffcio_rename);

    display = Display_open(Display_Type_UART, NULL);
    if (display == NULL) {
        while (1);
    }

    clock_settime(CLOCK_REALTIME, &ts);
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    Display_printf(display, 0, 0, "\n--- MSP432E4 Internal Flash FAT File System ---\n");

    /* Mount the internal flash drive */
    fresult = f_mount(&g_fatFs, "0:", 1);
    if (fresult == FR_NO_FILESYSTEM) {
        Display_printf(display, 0, 0, "No filesystem found. Formatting 256KB flash area...\n");
        BYTE workBuf[FF_MAX_SS];
        fresult = f_mkfs("0:", FM_FAT, 0, workBuf, sizeof(workBuf));
        if (fresult != FR_OK) {
            Display_printf(display, 0, 0, "f_mkfs failed with code: %d\n", fresult);
            while (1);
        }
        Display_printf(display, 0, 0, "Format complete. Re-mounting...\n");
        fresult = f_mount(&g_fatFs, "0:", 1);
    }

    if (fresult != FR_OK) {
        Display_printf(display, 0, 0, "Mount failed with code: %d\n", fresult);
        while (1);
    }

    Display_printf(display, 0, 0, "Drive %u mounted successfully.\n", DRIVE_NUM);

    /* Open or generate input file */
    src = fopen(inputfile, "r");
    if (!src) {
        Display_printf(display, 0, 0, "Creating \"%s\"...\n", inputfile);
        src = fopen(inputfile, "w+");
        if (!src) {
            Display_printf(display, 0, 0, "Error: could not create \"%s\"\n", inputfile);
            while (1);
        }
        fwrite(textarray, 1, strlen(textarray), src);
        fflush(src);
        rewind(src);
        Display_printf(display, 0, 0, "File created.\n");
    } else {
        Display_printf(display, 0, 0, "Using existing copy of \"%s\"\n", inputfile);
    }

    /* Copy inputfile to outputfile */
    dst = fopen(outputfile, "w");
    if (!dst) {
        Display_printf(display, 0, 0, "Error opening \"%s\"\n", outputfile);
        while (1);
    }

    while (true) {
        bytesRead = fread(cpy_buff, 1, CPY_BUFF_SIZE, src);
        if (bytesRead == 0) {
            break;
        }

        bytesWritten = fwrite(cpy_buff, 1, bytesRead, dst);
        if (bytesWritten < bytesRead) {
            Display_printf(display, 0, 0, "Disk Full\n");
            break;
        }
        totalBytesCopied += bytesWritten;
    }

    fflush(dst);

    fseek(src, 0, SEEK_END);
    filesize = ftell(src);
    rewind(src);

    fclose(src);
    fclose(dst);

    Display_printf(display, 0, 0, "Copied %u bytes to \"%s\".\n", totalBytesCopied, outputfile);

    /* Read back content from destination file to UART */
    dst = fopen(outputfile, "r");
    if (!dst) {
        Display_printf(display, 0, 0, "Error re-opening \"%s\"\n", outputfile);
        while (1);
    }

    while (true) {
        bytesRead = fread(cpy_buff, 1, CPY_BUFF_SIZE, dst);
        if (bytesRead == 0) {
            break;
        }
        cpy_buff[bytesRead] = '\0';
        Display_printf(display, 0, 0, "%s", cpy_buff);
    }

    fclose(dst);

    f_mount(NULL, "0:", 0);
    Display_printf(display, 0, 0, "Drive %u unmounted successfully.\n", DRIVE_NUM);

    return NULL;
}

int32_t fatfs_getFatTime(void)
{
    time_t seconds = time(NULL);
    struct tm *pTime = localtime(&seconds);

    uint32_t fatTime = ((uint32_t)(pTime->tm_year - 80) << 25) |
                       ((uint32_t)(pTime->tm_mon) << 21) |
                       ((uint32_t)(pTime->tm_mday) << 16) |
                       ((uint32_t)(pTime->tm_hour) << 11) |
                       ((uint32_t)(pTime->tm_min) << 5) |
                       ((uint32_t)(pTime->tm_sec) >> 1);

    return ((int32_t)fatTime);
}



#if FF_FS_REENTRANT

/* Create a synchronization object (FreeRTOS mutex) */
int ff_cre_syncobj(BYTE vol, FF_SYNC_t *sobj)
{
    *sobj = xSemaphoreCreateMutex();
    return (*sobj != NULL) ? 1 : 0;
}

/* Delete synchronization object */
int ff_del_syncobj(FF_SYNC_t sobj)
{
    vSemaphoreDelete(sobj);
    return 1;
}

/* Request grant to access the volume */
int ff_req_grant(FF_SYNC_t sobj)
{
    return (xSemaphoreTake(sobj, pdMS_TO_TICKS(FF_FS_TIMEOUT)) == pdTRUE) ? 1 : 0;
}

/* Release grant */
void ff_rel_grant(FF_SYNC_t sobj)
{
    xSemaphoreGive(sobj);
}

#endif /* FF_FS_REENTRANT */

/* Real-Time Clock / Timestamp provider required by FatFs */
DWORD get_fattime(void)
{
    time_t seconds = time(NULL);
    struct tm *pTime = localtime(&seconds);

    uint32_t fatTime = ((uint32_t)(pTime->tm_year - 80) << 25) |
                       ((uint32_t)(pTime->tm_mon) << 21) |
                       ((uint32_t)(pTime->tm_mday) << 16) |
                       ((uint32_t)(pTime->tm_hour) << 11) |
                       ((uint32_t)(pTime->tm_min) << 5) |
                       ((uint32_t)(pTime->tm_sec) >> 1);

    return (DWORD)fatTime;
}
