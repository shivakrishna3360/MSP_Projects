# FIXED

fatsd.obj: ../fatsd.c
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/file.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdio.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdlib.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h
fatsd.obj: D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/semphr.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/queue.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h
fatsd.obj: C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h
fatsd.obj: D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/fat_driver/ff.h
fatsd.obj: D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/fat_driver/integer.h
fatsd.obj: D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/fat_driver/ffconf.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/pthread.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sched.h
fatsd.obj: D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/fat_driver/ffcio.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h
fatsd.obj: D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/Debug/syscfg/ti_drivers_config.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h

../fatsd.c: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/file.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdio.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdlib.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/FreeRTOS.h: 
D:/MSP/freertos_builds_MSP_EXP432E401Y_release_ccs/FreeRTOSConfig.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/freertos/PTLS.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/projdefs.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/portable.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/deprecated_definitions.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/portable/CCS/ARM_CM4F/portmacro.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/mpu_wrappers.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/semphr.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/queue.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/task.h: 
C:/ti/FreeRTOSv10.1.1/FreeRTOS/Source/include/list.h: 
D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/fat_driver/ff.h: 
D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/fat_driver/integer.h: 
D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/fat_driver/ffconf.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/pthread.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sched.h: 
D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/fat_driver/ffcio.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h: 
D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/Debug/syscfg/ti_drivers_config.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h: 
