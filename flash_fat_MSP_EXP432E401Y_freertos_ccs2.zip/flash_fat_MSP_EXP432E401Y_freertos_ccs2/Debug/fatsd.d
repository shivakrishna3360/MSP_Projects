# FIXED

fatsd.obj: ../fatsd.c
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/file.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdio.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdlib.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h
fatsd.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/pthread.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sched.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ff.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/integer.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ffconf.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ffcio.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h
fatsd.obj: D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/Debug/syscfg/ti_drivers_config.h
fatsd.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h

../fatsd.c: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/file.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdio.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdlib.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/string.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/time.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/abi_prefix.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/xlocale/_time.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/signal.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/types.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sys/_internal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/signal.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/../include/sys/timespec.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_timespec.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/pthread.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/posix/ccs/sched.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ff.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/integer.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ffconf.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ffcio.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h: 
D:/MSP/flash_fat_MSP_EXP432E401Y_freertos_ccs2/Debug/syscfg/ti_drivers_config.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h: 
