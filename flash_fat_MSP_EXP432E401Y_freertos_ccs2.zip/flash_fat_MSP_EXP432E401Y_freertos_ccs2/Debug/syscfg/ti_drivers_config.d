# FIXED

syscfg/ti_drivers_config.obj: syscfg/ti_drivers_config.c
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h
syscfg/ti_drivers_config.obj: syscfg/ti_drivers_config.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/DisplayUart.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/SemaphoreP.h
syscfg/ti_drivers_config.obj: C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/UART.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dma/UDMAMSP432E4.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/HwiP.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432e401y.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/core_cm4.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_version.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_compiler.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_ccs.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/mpu_armv7.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/system_msp432e401y.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/interrupt.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/udma.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/gpio/GPIOMSP432E4.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/gpio.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Power.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/utils/List.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/power/PowerMSP432E4.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/SD.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/sd/SDSPI.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/SPI.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/SDFatFS.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ff.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/integer.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ffconf.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/diskio.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/spi/SPIMSP432E4DMA.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pin_map.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/adc.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pwm.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/sysctl.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/uart/UARTMSP432E4.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/ClockP.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/utils/RingBuf.h
syscfg/ti_drivers_config.obj: C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Board.h

syscfg/ti_drivers_config.c: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stddef.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_ti_config.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/linkage.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/_stdint40.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/cdefs.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_types.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/machine/_stdint.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/sys/_stdint.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/DeviceFamily.h: 
syscfg/ti_drivers_config.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/Display.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdarg.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/display/DisplayUart.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/SemaphoreP.h: 
C:/ti/ccs1010/ccs/tools/compiler/ti-cgt-arm_20.2.1.LTS/include/stdbool.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/UART.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dma/UDMAMSP432E4.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/HwiP.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/msp432e401y.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/core_cm4.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_version.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_compiler.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/cmsis_ccs.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/CMSIS/Include/mpu_armv7.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/inc/system_msp432e401y.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/interrupt.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/udma.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/GPIO.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/gpio/GPIOMSP432E4.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/gpio.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Power.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/utils/List.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/power/PowerMSP432E4.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/SD.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/sd/SDSPI.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/SPI.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/SDFatFS.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ff.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/integer.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/ffconf.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/third_party/fatfs/diskio.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/spi/SPIMSP432E4DMA.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pin_map.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/adc.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/pwm.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/devices/msp432e4/driverlib/sysctl.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/uart/UARTMSP432E4.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/dpl/ClockP.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/utils/RingBuf.h: 
C:/ti/simplelink_msp432e4_sdk_4_20_00_12/source/ti/drivers/Board.h: 
